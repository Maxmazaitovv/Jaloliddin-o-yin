package com.tarix.manguberdi;

import android.content.Context;
import android.content.SharedPreferences;

public class SaveManager {
    private static final String PREFS = "manguberdi_save_v2";
    private final SharedPreferences prefs;

    public SaveManager(Context context) {
        this.prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public void saveProgress(int chapter, int gold, int swordLevel, int armorLevel, int totalDefeated) {
        prefs.edit()
                .putInt("chapter", chapter)
                .putInt("gold", gold)
                .putInt("swordLevel", swordLevel)
                .putInt("armorLevel", armorLevel)
                .putInt("totalDefeated", totalDefeated)
                .apply();
    }

    public int getChapter() {
        return prefs.getInt("chapter", 1);
    }

    public int getGold() {
        return prefs.getInt("gold", 0);
    }

    public int getSwordLevel() {
        return prefs.getInt("swordLevel", 1);
    }

    public int getArmorLevel() {
        return prefs.getInt("armorLevel", 1);
    }

    public int getTotalDefeated() {
        return prefs.getInt("totalDefeated", 0);
    }

    public void reset() {
        prefs.edit().clear().apply();
    }
}
