package com.tarix.manguberdi;

public class Particle {
    public float x;
    public float y;
    public float vx;
    public float vy;
    public float life;
    public int color;

    public Particle(float x, float y, float vx, float vy, float life, int color) {
        this.x = x;
        this.y = y;
        this.vx = vx;
        this.vy = vy;
        this.life = life;
        this.color = color;
    }
}
