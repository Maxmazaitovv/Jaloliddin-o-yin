package com.tarix.manguberdi;

public class Enemy {
    public static final int TYPE_WARRIOR = 0;
    public static final int TYPE_ARCHER = 1;
    public static final int TYPE_BOSS = 2;

    public int type;
    public float x;
    public float y;
    public float speed;
    public int hp;
    public int maxHp;
    public float attackCooldown = 0f;
    public float hitFlash = 0f;
    public String title;

    public Enemy(int type, float x, float y, float speed, int hp, String title) {
        this.type = type;
        this.x = x;
        this.y = y;
        this.speed = speed;
        this.hp = hp;
        this.maxHp = hp;
        this.title = title;
    }

    public boolean isAlive() {
        return hp > 0;
    }

    public boolean isBoss() {
        return type == TYPE_BOSS;
    }
}
