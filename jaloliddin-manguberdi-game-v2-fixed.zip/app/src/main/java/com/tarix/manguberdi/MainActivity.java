package com.tarix.manguberdi;

import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements GameView.GameListener {

    private GameView gameView;
    private SaveManager saveManager;
    private SoundEffects soundEffects;

    private TextView tvStats;
    private ScrollView storyOverlay;
    private TextView tvStoryTitle;
    private TextView tvStoryBody;
    private Button btnContinue;

    private LinearLayout upgradeOverlay;
    private TextView tvUpgradeInfo;
    private boolean defeatedState = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        saveManager = new SaveManager(this);
        soundEffects = new SoundEffects();

        gameView = findViewById(R.id.gameView);
        tvStats = findViewById(R.id.tvStats);
        storyOverlay = findViewById(R.id.storyOverlay);
        tvStoryTitle = findViewById(R.id.tvStoryTitle);
        tvStoryBody = findViewById(R.id.tvStoryBody);
        btnContinue = findViewById(R.id.btnContinue);

        upgradeOverlay = findViewById(R.id.upgradeOverlay);
        tvUpgradeInfo = findViewById(R.id.tvUpgradeInfo);

        Button btnLeft = findViewById(R.id.btnLeft);
        Button btnRight = findViewById(R.id.btnRight);
        Button btnShield = findViewById(R.id.btnShield);
        Button btnDash = findViewById(R.id.btnDash);
        Button btnSpecial = findViewById(R.id.btnSpecial);
        Button btnAttack = findViewById(R.id.btnAttack);

        Button btnStory = findViewById(R.id.btnStory);
        Button btnSound = findViewById(R.id.btnSound);
        Button btnUpgrade = findViewById(R.id.btnUpgrade);
        Button btnUpSword = findViewById(R.id.btnUpSword);
        Button btnUpArmor = findViewById(R.id.btnUpArmor);
        Button btnCloseUpgrade = findViewById(R.id.btnCloseUpgrade);
        Button btnResetProgress = findViewById(R.id.btnResetProgress);

        gameView.initSystems(saveManager, soundEffects, this);

        btnLeft.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                gameView.setMoveDir(-1);
                return true;
            } else if (event.getAction() == MotionEvent.ACTION_UP || event.getAction() == MotionEvent.ACTION_CANCEL) {
                gameView.setMoveDir(0);
                return true;
            }
            return false;
        });

        btnRight.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                gameView.setMoveDir(1);
                return true;
            } else if (event.getAction() == MotionEvent.ACTION_UP || event.getAction() == MotionEvent.ACTION_CANCEL) {
                gameView.setMoveDir(0);
                return true;
            }
            return false;
        });

        btnShield.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                gameView.setShieldActive(true);
                return true;
            } else if (event.getAction() == MotionEvent.ACTION_UP || event.getAction() == MotionEvent.ACTION_CANCEL) {
                gameView.setShieldActive(false);
                return true;
            }
            return false;
        });

        btnDash.setOnClickListener(v -> gameView.triggerJumpOrDash());
        btnSpecial.setOnClickListener(v -> gameView.triggerSpecialStorm());
        btnAttack.setOnClickListener(v -> gameView.triggerSwordAttack());

        btnSound.setOnClickListener(v -> {
            boolean next = !soundEffects.isEnabled();
            soundEffects.setEnabled(next);
            btnSound.setText(next ? "Ovoz: ON" : "Ovoz: OFF");
        });

        btnStory.setOnClickListener(v -> openStory(gameView.getChapter(), false));

        btnUpgrade.setOnClickListener(v -> {
            gameView.setPausedForOverlay(true);
            refreshUpgradeInfo();
            upgradeOverlay.setVisibility(View.VISIBLE);
        });

        btnUpSword.setOnClickListener(v -> {
            if (gameView.upgradeSword()) {
                refreshUpgradeInfo();
                Toast.makeText(this, "Qilich kuchaytirildi!", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Oltin yetarli emas (30 oltin kerak)", Toast.LENGTH_SHORT).show();
            }
        });

        btnUpArmor.setOnClickListener(v -> {
            if (gameView.upgradeArmor()) {
                refreshUpgradeInfo();
                Toast.makeText(this, "Sovut mustahkamlandi!", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Oltin yetarli emas (30 oltin kerak)", Toast.LENGTH_SHORT).show();
            }
        });

        btnCloseUpgrade.setOnClickListener(v -> {
            upgradeOverlay.setVisibility(View.GONE);
            gameView.setPausedForOverlay(false);
        });

        btnContinue.setOnClickListener(v -> {
            storyOverlay.setVisibility(View.GONE);
            if (defeatedState) {
                defeatedState = false;
                gameView.retryCurrentChapter();
            } else {
                gameView.setPausedForOverlay(false);
            }
        });

        btnResetProgress.setOnClickListener(v -> {
            gameView.resetAllProgress();
            openStory(1, false);
        });

        openStory(gameView.getChapter(), false);
    }

    private void refreshUpgradeInfo() {
        tvUpgradeInfo.setText("Oltin: " + gameView.getGold()
                + "  |  Qilich darajasi: " + gameView.getSwordLevel()
                + "  |  Sovut darajasi: " + gameView.getArmorLevel());
    }

    private void openStory(int chapter, boolean isDefeat) {
        defeatedState = isDefeat;
        gameView.setPausedForOverlay(true);
        if (isDefeat) {
            tvStoryTitle.setText("JANGDA MAG'LUBIYAT");
            tvStoryBody.setText("Jaloliddin Manguberdi bu jangda og'ir zarba oldi. "
                    + "Qayta urinib ko'ring yoki Kuchaytirish bo'limidan qurollaringizni yaxshilang.");
            btnContinue.setText("Bobni qayta boshlash");
        } else {
            tvStoryTitle.setText(StoryData.getChapterTitle(chapter));
            tvStoryBody.setText(StoryData.getChapterText(chapter));
            btnContinue.setText("Jangga kirish");
        }
        storyOverlay.setVisibility(View.VISIBLE);
    }

    @Override
    public void onStatsUpdated(int hp, int maxHp, int spirit, int gold, int chapter, int bossHp, int bossMaxHp) {
        String text = "Jon: " + hp + "/" + maxHp
                + " | Ruh: " + spirit
                + " | Oltin: " + gold
                + " | Bob: " + chapter;
        if (bossMaxHp > 0) {
            text += " | BOSS: " + bossHp + "/" + bossMaxHp;
        }
        tvStats.setText(text);
    }

    @Override
    public void onChapterComplete(int nextChapter) {
        gameView.startNextChapter();
        openStory(nextChapter, false);
    }

    @Override
    public void onPlayerDefeated() {
        openStory(gameView.getChapter(), true);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (soundEffects != null) {
            soundEffects.release();
        }
    }
}
