package com.tarix.manguberdi;

public class Projectile {
    public float x;
    public float y;
    public float vx;
    public int damage;
    public boolean fromPlayer;

    public Projectile(float x, float y, float vx, int damage, boolean fromPlayer) {
        this.x = x;
        this.y = y;
        this.vx = vx;
        this.damage = damage;
        this.fromPlayer = fromPlayer;
    }
}
