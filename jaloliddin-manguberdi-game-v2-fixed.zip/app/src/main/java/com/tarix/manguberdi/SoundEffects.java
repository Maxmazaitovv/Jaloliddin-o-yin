package com.tarix.manguberdi;

import android.media.AudioManager;
import android.media.ToneGenerator;

public class SoundEffects {
    private ToneGenerator toneGen;
    private boolean enabled = true;

    public SoundEffects() {
        try {
            toneGen = new ToneGenerator(AudioManager.STREAM_MUSIC, 75);
        } catch (Exception ignored) {
            toneGen = null;
        }
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void playSlash() {
        playTone(ToneGenerator.TONE_PROP_BEEP, 70);
    }

    public void playSpecial() {
        playTone(ToneGenerator.TONE_CDMA_EMERGENCY_RINGBACK, 160);
    }

    public void playHit() {
        playTone(ToneGenerator.TONE_PROP_NACK, 90);
    }

    public void playVictory() {
        playTone(ToneGenerator.TONE_PROP_ACK, 200);
    }

    private void playTone(int toneType, int durationMs) {
        if (!enabled || toneGen == null) return;
        try {
            toneGen.startTone(toneType, durationMs);
        } catch (Exception ignored) {
        }
    }

    public void release() {
        if (toneGen != null) {
            try {
                toneGen.release();
            } catch (Exception ignored) {
            }
            toneGen = null;
        }
    }
}
