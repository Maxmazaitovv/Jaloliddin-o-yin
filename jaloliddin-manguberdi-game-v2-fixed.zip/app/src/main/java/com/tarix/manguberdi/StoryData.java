package com.tarix.manguberdi;

public class StoryData {

    public static String getChapterTitle(int chapter) {
        switch (chapter) {
            case 1:
                return "I BOB: XORAZM DARVOZALARI (1221-YIL)";
            case 2:
                return "II BOB: PARVON JANGI VA TOG' DARA";
            case 3:
                return "III BOB: SIND DARYOSI BO'YIDAGI BOSS";
            default:
                return chapter + "-BOB: ABADIY JASORAT MAYDONI";
        }
    }

    public static String getChapterText(int chapter) {
        switch (chapter) {
            case 1:
                return "Mo'g'ul qo'shinlari Xorazm shaharlarini qamal qilgan bir paytda Sulton Jaloliddin Manguberdi "
                        + "o'z sodiq navkarlari bilan dushman halqasini yorib chiqadi.\n\n"
                        + "• 'Qalqon' — dushman zarbalarini to'sadi.\n"
                        + "• 'Sakrash' — havoda ikkinchi marta bosilsa tezkor oldinga otiladi.\n"
                        + "• 'Bo'ron ⚡' — 60 Ruh evaziga atrofdagi barcha dushmanlarga kuchli zarba beradi.";
            case 2:
                return "Parvon tog' daralarida Jaloliddin qo'shini dushmanning ilg'or qismlarini pistirmaga tushiradi. "
                        + "Endi kamonchilar va og'ir zirhli sarkardalar ham jangga kiradi.\n\n"
                        + "Yig'ilgan oltinlar evaziga 'Kuchaytirish' menyusidan qilich va sovutingizni yaxshilang!";
            case 3:
                return "Sind daryosi sohilida ulkan sarkarda — Mo'g'ul No'yoni qo'shin bilan yo'lni to'sdi. "
                        + "Uning zarbalari kuchli, shuning uchun Qalqon va Sakrashdan o'z vaqtida foydalaning.";
            default:
                return "Siz tarixiy g'alabalardan so'ng yangi sinov bosqichiga kirdingiz. "
                        + "Har bir bobda dushmanlar yanada kuchayadi va ko'proq oltin qoldiradi.";
        }
    }
}
