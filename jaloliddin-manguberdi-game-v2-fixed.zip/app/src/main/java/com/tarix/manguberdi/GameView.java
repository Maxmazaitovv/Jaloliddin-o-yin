package com.tarix.manguberdi;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

public class GameView extends SurfaceView implements SurfaceHolder.Callback, Runnable {

    public interface GameListener {
        void onStatsUpdated(int hp, int maxHp, int spirit, int gold, int chapter, int bossHp, int bossMaxHp);
        void onChapterComplete(int nextChapter);
        void onPlayerDefeated();
    }

    private Thread gameThread;
    private volatile boolean isRunning = false;
    private final SurfaceHolder holder;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Random random = new Random();

    private GameListener listener;
    private SaveManager saveManager;
    private SoundEffects soundEffects;

    private boolean pausedForOverlay = false;

    private int width = 1280;
    private int height = 720;
    private float groundY = 540f;
    private float animTime = 0f;

    // Qahramon (Jaloliddin)
    private float playerX = 240f;
    private float playerY = 540f;
    private float playerVy = 0f;
    private boolean isGrounded = true;
    private boolean facingRight = true;
    private boolean shieldActive = false;
    private int moveDir = 0;

    // Progress va statistikalar
    private int chapter = 1;
    private int gold = 0;
    private int swordLevel = 1;
    private int armorLevel = 1;
    private int totalDefeated = 0;

    private int maxHp = 100;
    private int hp = 100;
    private int spirit = 100;

    private int chapterKills = 0;
    private int killsBeforeBoss = 6;
    private boolean bossSpawned = false;

    private float attackTimer = 0f;
    private float attackCooldown = 0f;
    private float specialTimer = 0f;
    private float invulnTimer = 0f;
    private float spawnTimer = 0f;
    private float screenShake = 0f;

    private final List<Enemy> enemies = new ArrayList<>();
    private final List<Projectile> projectiles = new ArrayList<>();
    private final List<Particle> particles = new ArrayList<>();

    public GameView(Context context) {
        super(context);
        this.holder = getHolder();
        this.holder.addCallback(this);
    }

    public GameView(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.holder = getHolder();
        this.holder.addCallback(this);
    }

    public void initSystems(SaveManager saveManager, SoundEffects soundEffects, GameListener listener) {
        this.saveManager = saveManager;
        this.soundEffects = soundEffects;
        this.listener = listener;
        loadFromSave();
    }

    public void loadFromSave() {
        if (saveManager != null) {
            chapter = saveManager.getChapter();
            gold = saveManager.getGold();
            swordLevel = saveManager.getSwordLevel();
            armorLevel = saveManager.getArmorLevel();
            totalDefeated = saveManager.getTotalDefeated();
        }
        setupChapterState();
    }

    private void setupChapterState() {
        maxHp = 100 + (armorLevel - 1) * 25;
        hp = maxHp;
        spirit = 100;
        chapterKills = 0;
        killsBeforeBoss = 5 + chapter * 2;
        bossSpawned = false;
        playerX = 240f;
        playerY = groundY;
        playerVy = 0f;
        isGrounded = true;
        enemies.clear();
        projectiles.clear();
        particles.clear();
        notifyStats();
    }

    public int getChapter() {
        return chapter;
    }

    public int getGold() {
        return gold;
    }

    public int getSwordLevel() {
        return swordLevel;
    }

    public int getArmorLevel() {
        return armorLevel;
    }

    public boolean upgradeSword() {
        if (gold < 30) return false;
        gold -= 30;
        swordLevel++;
        persistSave();
        notifyStats();
        return true;
    }

    public boolean upgradeArmor() {
        if (gold < 30) return false;
        gold -= 30;
        armorLevel++;
        maxHp = 100 + (armorLevel - 1) * 25;
        hp = Math.min(maxHp, hp + 35);
        persistSave();
        notifyStats();
        return true;
    }

    public void resetAllProgress() {
        if (saveManager != null) {
            saveManager.reset();
        }
        chapter = 1;
        gold = 0;
        swordLevel = 1;
        armorLevel = 1;
        totalDefeated = 0;
        setupChapterState();
    }

    private void persistSave() {
        if (saveManager != null) {
            saveManager.saveProgress(chapter, gold, swordLevel, armorLevel, totalDefeated);
        }
    }

    public void setPausedForOverlay(boolean paused) {
        this.pausedForOverlay = paused;
        if (paused) {
            moveDir = 0;
            shieldActive = false;
        }
    }

    public void setMoveDir(int dir) {
        this.moveDir = dir;
        if (dir != 0) {
            facingRight = dir > 0;
        }
    }

    public void setShieldActive(boolean active) {
        this.shieldActive = active;
    }

    public void triggerJumpOrDash() {
        if (pausedForOverlay) return;
        if (isGrounded) {
            playerVy = -880f;
            isGrounded = false;
            invulnTimer = 0.25f;
            spawnDust(playerX, groundY, 8);
        } else if (spirit >= 20) {
            spirit -= 20;
            float dashDelta = facingRight ? 150f : -150f;
            playerX = Math.max(70f, Math.min(width - 110f, playerX + dashDelta));
            invulnTimer = 0.40f;
            spawnDust(playerX, playerY - 30f, 12);
            notifyStats();
        }
    }

    public void triggerSwordAttack() {
        if (pausedForOverlay || attackCooldown > 0f) return;
        attackTimer = 0.22f;
        attackCooldown = 0.34f;
        if (soundEffects != null) soundEffects.playSlash();

        int baseDamage = 32 + (swordLevel - 1) * 12;
        if (spirit >= 60) baseDamage += 14;

        float reach = 155f;
        float attackCenterX = facingRight ? (playerX + 80f) : (playerX - 80f);

        Iterator<Enemy> it = enemies.iterator();
        while (it.hasNext()) {
            Enemy e = it.next();
            float dx = Math.abs(e.x - attackCenterX);
            float dy = Math.abs(e.y - playerY);
            if (dx <= reach && dy <= 115f) {
                damageEnemy(e, baseDamage, it);
            }
        }
        notifyStats();
    }

    public void triggerSpecialStorm() {
        if (pausedForOverlay || spirit < 60) return;
        spirit -= 60;
        specialTimer = 0.45f;
        screenShake = 0.25f;
        invulnTimer = 0.50f;
        if (soundEffects != null) soundEffects.playSpecial();

        int stormDamage = 65 + (swordLevel - 1) * 18;
        spawnSparks(playerX, playerY - 45f, Color.rgb(255, 200, 60), 26);

        Iterator<Enemy> it = enemies.iterator();
        while (it.hasNext()) {
            Enemy e = it.next();
            if (Math.abs(e.x - playerX) <= 320f) {
                damageEnemy(e, stormDamage, it);
            }
        }
        notifyStats();
    }

    private void damageEnemy(Enemy e, int dmg, Iterator<Enemy> it) {
        e.hp -= dmg;
        e.hitFlash = 0.16f;
        if (!e.isBoss()) {
            e.x += facingRight ? 40f : -40f;
        }
        spawnSparks(e.x, e.y - 45f, Color.rgb(255, 95, 75), 10);

        if (!e.isAlive()) {
            boolean wasBoss = e.isBoss();
            it.remove();
            chapterKills++;
            totalDefeated++;
            gold += wasBoss ? (40 + chapter * 10) : (8 + chapter * 2);
            spirit = Math.min(100, spirit + (wasBoss ? 40 : 16));
            hp = Math.min(maxHp, hp + (wasBoss ? 30 : 6));
            if (soundEffects != null) soundEffects.playVictory();

            if (wasBoss) {
                chapter++;
                persistSave();
                pausedForOverlay = true;
                final int nextCh = chapter;
                post(() -> {
                    if (listener != null) listener.onChapterComplete(nextCh);
                });
            }
        }
    }

    public void startNextChapter() {
        setupChapterState();
        pausedForOverlay = false;
    }

    public void retryCurrentChapter() {
        setupChapterState();
        pausedForOverlay = false;
    }

    private void spawnSparks(float x, float y, int color, int count) {
        for (int i = 0; i < count; i++) {
            float vx = (random.nextFloat() - 0.5f) * 340f;
            float vy = -random.nextFloat() * 260f;
            particles.add(new Particle(x, y, vx, vy, 0.35f + random.nextFloat() * 0.25f, color));
        }
    }

    private void spawnDust(float x, float y, int count) {
        for (int i = 0; i < count; i++) {
            float vx = (random.nextFloat() - 0.5f) * 180f;
            float vy = -random.nextFloat() * 90f;
            particles.add(new Particle(x, y, vx, vy, 0.30f, Color.rgb(190, 150, 100)));
        }
    }

    private void notifyStats() {
        if (listener != null) {
            int bHp = 0;
            int bMax = 0;
            for (Enemy e : enemies) {
                if (e.isBoss()) {
                    bHp = e.hp;
                    bMax = e.maxHp;
                    break;
                }
            }
            final int fHp = hp, fMax = maxHp, fSp = spirit, fGold = gold, fCh = chapter, fbHp = bHp, fbMax = bMax;
            post(() -> listener.onStatsUpdated(fHp, fMax, fSp, fGold, fCh, fbHp, fbMax));
        }
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        if (w > 0 && h > 0) {
            width = w;
            height = h;
            groundY = height * 0.77f;
            if (isGrounded) playerY = groundY;
        }
    }

    @Override
    public void surfaceCreated(SurfaceHolder surfaceHolder) {
        isRunning = true;
        gameThread = new Thread(this);
        gameThread.start();
    }

    @Override
    public void surfaceChanged(SurfaceHolder surfaceHolder, int format, int w, int h) {
        if (w > 0 && h > 0) {
            width = w;
            height = h;
            groundY = height * 0.77f;
        }
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder surfaceHolder) {
        isRunning = false;
        try {
            if (gameThread != null) gameThread.join();
        } catch (InterruptedException ignored) {
        }
    }

    @Override
    public void run() {
        long lastTime = System.nanoTime();
        while (isRunning) {
            long now = System.nanoTime();
            float dt = (now - lastTime) / 1_000_000_000f;
            lastTime = now;
            if (dt > 0.05f) dt = 0.05f;

            if (!pausedForOverlay) {
                update(dt);
            }
            renderFrame();
        }
    }

    private void update(float dt) {
        animTime += dt;
        float speed = shieldActive ? 170f : 350f;
        playerX += moveDir * speed * dt;
        playerX = Math.max(70f, Math.min(width - 110f, playerX));

        if (!isGrounded) {
            playerVy += 2150f * dt;
            playerY += playerVy * dt;
            if (playerY >= groundY) {
                playerY = groundY;
                playerVy = 0f;
                isGrounded = true;
            }
        } else {
            playerY = groundY;
        }

        if (attackTimer > 0f) attackTimer -= dt;
        if (attackCooldown > 0f) attackCooldown -= dt;
        if (specialTimer > 0f) specialTimer -= dt;
        if (invulnTimer > 0f) invulnTimer -= dt;
        if (screenShake > 0f) screenShake -= dt;

        // Ruhiy kuch asta-sekin tiklanadi
        if (random.nextFloat() < dt * 4f && spirit < 100) {
            spirit = Math.min(100, spirit + 1);
            notifyStats();
        }

        // Boss yoki oddiy dushmanlarni chiqarish
        if (!bossSpawned && chapterKills >= killsBeforeBoss && enemies.isEmpty()) {
            bossSpawned = true;
            int bossHp = 220 + (chapter - 1) * 90;
            enemies.add(new Enemy(Enemy.TYPE_BOSS, width - 130f, groundY, 105f + chapter * 10f, bossHp, "Mo'g'ul No'yoni"));
            notifyStats();
        } else if (!bossSpawned) {
            spawnTimer -= dt;
            int maxEnemies = Math.min(4, 2 + chapter / 2);
            if (spawnTimer <= 0f && enemies.size() < maxEnemies && (chapterKills + enemies.size()) < killsBeforeBoss) {
                spawnTimer = Math.max(1.2f, 2.5f - chapter * 0.15f);
                float spawnX = random.nextBoolean() ? (width - 60f) : 60f;
                boolean spawnArcher = (chapter >= 2 && random.nextFloat() < 0.35f);
                if (spawnArcher) {
                    enemies.add(new Enemy(Enemy.TYPE_ARCHER, spawnX, groundY, 95f, 55 + chapter * 12, "Kamonchi"));
                } else {
                    enemies.add(new Enemy(Enemy.TYPE_WARRIOR, spawnX, groundY, 135f + chapter * 18f, 70 + chapter * 16, "Navkar"));
                }
            }
        }

        boolean statsChanged = false;
        for (Enemy e : enemies) {
            if (e.hitFlash > 0f) e.hitFlash -= dt;
            if (e.attackCooldown > 0f) e.attackCooldown -= dt;

            float dx = playerX - e.x;
            float dist = Math.abs(dx);

            if (e.type == Enemy.TYPE_ARCHER) {
                if (dist > 360f) {
                    e.x += Math.signum(dx) * e.speed * dt;
                } else if (e.attackCooldown <= 0f) {
                    e.attackCooldown = 2.4f;
                    float arrowVx = Math.signum(dx) * (390f + chapter * 25f);
                    projectiles.add(new Projectile(e.x, e.y - 52f, arrowVx, 10 + chapter * 2, false));
                }
            } else {
                float stopRange = e.isBoss() ? 78f : 56f;
                if (dist > stopRange) {
                    e.x += Math.signum(dx) * e.speed * dt;
                } else if (e.attackCooldown <= 0f && Math.abs(playerY - e.y) < 65f) {
                    e.attackCooldown = e.isBoss() ? 1.35f : 1.15f;
                    int rawDmg = e.isBoss() ? (18 + chapter * 4) : (10 + chapter * 2);
                    applyPlayerDamage(rawDmg);
                    statsChanged = true;
                }
            }
        }

        // Kamon o'qlarini yangilash
        Iterator<Projectile> pIt = projectiles.iterator();
        while (pIt.hasNext()) {
            Projectile p = pIt.next();
            p.x += p.vx * dt;
            if (p.x < 0 || p.x > width) {
                pIt.remove();
                continue;
            }
            if (!p.fromPlayer && Math.abs(p.x - playerX) < 28f && Math.abs(p.y - (playerY - 45f)) < 42f) {
                pIt.remove();
                applyPlayerDamage(p.damage);
                statsChanged = true;
            }
        }

        // Uchqun va chang zarralari
        Iterator<Particle> ptIt = particles.iterator();
        while (ptIt.hasNext()) {
            Particle pt = ptIt.next();
            pt.x += pt.vx * dt;
            pt.y += pt.vy * dt;
            pt.vy += 450f * dt;
            pt.life -= dt;
            if (pt.life <= 0f) ptIt.remove();
        }

        if (statsChanged) {
            notifyStats();
        }
    }

    private void applyPlayerDamage(int rawDamage) {
        if (invulnTimer > 0f) return;
        if (shieldActive && spirit >= 10) {
            spirit -= 10;
            rawDamage = Math.max(2, rawDamage / 4);
            spawnSparks(playerX + (facingRight ? 26f : -26f), playerY - 45f, Color.CYAN, 8);
        } else {
            invulnTimer = 0.45f;
            if (soundEffects != null) soundEffects.playHit();
        }
        hp -= rawDamage;
        if (hp <= 0) {
            hp = 0;
            pausedForOverlay = true;
            notifyStats();
            post(() -> {
                if (listener != null) listener.onPlayerDefeated();
            });
        }
    }

    private void renderFrame() {
        Canvas canvas = null;
        try {
            canvas = holder.lockCanvas();
            if (canvas == null) return;

            canvas.save();
            if (screenShake > 0f) {
                canvas.translate((random.nextFloat() - 0.5f) * 14f, (random.nextFloat() - 0.5f) * 14f);
            }

            // Osmon gradienti
            paint.setShader(new LinearGradient(0, 0, 0, groundY,
                    Color.rgb(20, 14, 12), Color.rgb(78, 46, 24), Shader.TileMode.CLAMP));
            canvas.drawRect(0, 0, width, groundY, paint);
            paint.setShader(null);

            // Uzoqdagi tog' va qal'a siluetlari
            paint.setColor(Color.rgb(42, 27, 18));
            Path hills = new Path();
            hills.moveTo(0, groundY);
            hills.lineTo(0, groundY - 120f);
            hills.lineTo(width * 0.25f, groundY - 190f);
            hills.lineTo(width * 0.55f, groundY - 110f);
            hills.lineTo(width * 0.80f, groundY - 210f);
            hills.lineTo(width, groundY - 130f);
            hills.lineTo(width, groundY);
            hills.close();
            canvas.drawPath(hills, paint);

            // Qadimiy minora silueti
            paint.setColor(Color.rgb(55, 36, 22));
            canvas.drawRect(width * 0.72f, groundY - 245f, width * 0.76f, groundY, paint);
            canvas.drawRect(width * 0.71f, groundY - 255f, width * 0.77f, groundY - 240f, paint);

            // Cho'l va yer qatlami
            paint.setColor(Color.rgb(118, 78, 38));
            canvas.drawRect(0, groundY, width, height, paint);
            paint.setColor(Color.rgb(172, 124, 66));
            canvas.drawRect(0, groundY, width, groundY + 10f, paint);

            // Bo'ron to'lqini effekti
            if (specialTimer > 0f) {
                paint.setStyle(Paint.Style.STROKE);
                paint.setStrokeWidth(8f);
                paint.setColor(Color.argb(190, 255, 215, 80));
                float radius = (0.45f - specialTimer) * 720f;
                canvas.drawCircle(playerX, playerY - 45f, radius, paint);
                paint.setStyle(Paint.Style.FILL);
            }

            // Qahramon (Jaloliddin Manguberdi)
            float bob = (moveDir != 0 && isGrounded) ? (float) Math.sin(animTime * 16f) * 4f : 0f;
            float pTop = playerY - 84f + bob;

            // Plash (yopinchiq)
            paint.setColor(Color.rgb(138, 28, 28));
            float capeDir = facingRight ? -1f : 1f;
            Path cape = new Path();
            cape.moveTo(playerX, pTop + 14f);
            cape.lineTo(playerX + capeDir * (34f + (float) Math.sin(animTime * 12f) * 6f), playerY - 12f);
            cape.lineTo(playerX + capeDir * 10f, playerY - 8f);
            cape.close();
            canvas.drawPath(cape, paint);

            // Tana va sovut
            paint.setColor(invulnTimer > 0f ? Color.rgb(255, 224, 130) : Color.rgb(36, 118, 156));
            canvas.drawRoundRect(new RectF(playerX - 22f, pTop, playerX + 22f, playerY), 10f, 10f, paint);

            // Oltin dubulg'a
            paint.setColor(Color.rgb(218, 178, 56));
            canvas.drawCircle(playerX, pTop - 14f, 16f, paint);

            // Qalqon
            if (shieldActive) {
                paint.setColor(Color.rgb(90, 195, 235));
                float shX = facingRight ? (playerX + 26f) : (playerX - 26f);
                canvas.drawRoundRect(new RectF(shX - 7f, pTop + 8f, shX + 7f, playerY - 14f), 6f, 6f, paint);
            }

            // Qilich zarbasi
            if (attackTimer > 0f) {
                paint.setColor(Color.rgb(255, 240, 165));
                float slashX = facingRight ? (playerX + 70f) : (playerX - 70f);
                canvas.drawArc(new RectF(slashX - 52f, pTop - 10f, slashX + 52f, playerY + 10f),
                        facingRight ? -75f : 105f, 150f, true, paint);
            }

            // Dushmanlar
            for (Enemy e : enemies) {
                float eW = e.isBoss() ? 34f : 22f;
                float eH = e.isBoss() ? 104f : 76f;

                int bodyColor = e.hitFlash > 0f ? Color.WHITE
                        : (e.isBoss() ? Color.rgb(112, 22, 118)
                        : (e.type == Enemy.TYPE_ARCHER ? Color.rgb(68, 115, 58) : Color.rgb(166, 38, 38)));

                paint.setColor(bodyColor);
                canvas.drawRoundRect(new RectF(e.x - eW, e.y - eH, e.x + eW, e.y), 9f, 9f, paint);

                paint.setColor(e.isBoss() ? Color.rgb(230, 180, 50) : Color.rgb(80, 22, 22));
                canvas.drawCircle(e.x, e.y - eH - 14f, e.isBoss() ? 20f : 14f, paint);

                // Jon chizig'i
                float ratio = Math.max(0f, (float) e.hp / e.maxHp);
                paint.setColor(Color.DKGRAY);
                canvas.drawRect(e.x - eW, e.y - eH - 42f, e.x + eW, e.y - eH - 34f, paint);
                paint.setColor(e.isBoss() ? Color.MAGENTA : Color.RED);
                canvas.drawRect(e.x - eW, e.y - eH - 42f, e.x - eW + (eW * 2f) * ratio, e.y - eH - 34f, paint);
            }

            // Kamon o'qlari
            paint.setColor(Color.rgb(245, 220, 150));
            for (Projectile p : projectiles) {
                canvas.drawRect(p.x - 16f, p.y - 3f, p.x + 16f, p.y + 3f, paint);
            }

            // Zarralar
            for (Particle pt : particles) {
                paint.setColor(pt.color);
                canvas.drawCircle(pt.x, pt.y, 4f, paint);
            }

            canvas.restore();
        } finally {
            if (canvas != null) {
                holder.unlockCanvasAndPost(canvas);
            }
        }
    }
}
